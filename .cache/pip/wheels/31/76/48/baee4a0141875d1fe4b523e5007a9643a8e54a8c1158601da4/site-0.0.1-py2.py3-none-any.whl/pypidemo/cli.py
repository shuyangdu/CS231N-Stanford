# -*- coding: utf-8 -*-
'''
Created on Mar 10, 2017

@author: hustcc
'''


def run():
    print('OK.')
